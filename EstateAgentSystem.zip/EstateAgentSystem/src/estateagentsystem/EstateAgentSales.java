package estateagentsystem;

public class EstateAgentSales extends EstateAgent{

    public EstateAgentSales(String agentName, double propertyPrice){
    super(agentName, propertyPrice);
    }
    
    public void printPropertyReport(){
        System.out.println("Console sales Report");
        System.out.println("***********************");
        System.out.println("Store Name:" + getAgentName());
        System.out.println("Property Price: R" + getPropertyPrice());
        System.out.println("Agent Commission: R" + getAgentCommission());
    }
}
