/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package estateagentsystem;
import java.util.Scanner;

public class RunApp {
    public static void main(String[] args){
        Scanner input = new Scanner(System.in);
        
        System.out.print("Enter the current Store name: ");
        String name = input.nextLine();
        
        System.out.print("Enter the total sales of PS5 consoles for store:");
        double price = input.nextDouble();
        
        EstateAgentSales agent = new EstateAgentSales(name, price);
        
        System.out.println();
        agent.printPropertyReport();
    
    }
}
