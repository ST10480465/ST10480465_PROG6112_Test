/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package consoletypes;

/**
 *
 * @author emeris
 */
public class ConsoleTypes {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
         String[] Cities = {"Cape Town","Port Elizabeth","Pretoria"};
         String[] Consoles = {"PS5","XBOX","SWITCH"};
       int[][] sales ={
        {1000,2000,3000},
        {2000,3000,4000},
        {1500,1100,1200}
        };
         
        int[] cityTotal = new int[Cities.length];
        int[] consoleTotals = new int[Consoles.length];
        
        
        System.out.println("----------------------------------------------------");
        System.out.println("Gaming Console Report");
        System.out.println("----------------------------------------------------");
        System.out.println("\t\tPS5\tXBOX\tSWITCH");
                
        for (int i = 0; i < Cities.length; i++){
            for (int j = 0; j < Consoles.length; j++){
                cityTotal[i]+= sales[i][j];
                consoleTotals[j]+= sales[i][j];
            
            }
        
        
        }        
        
        int bestCity = 0;
        for (int i = 1; i < Cities.length; i++){
        if (cityTotal[i]< cityTotal[bestCity]){
            bestCity = i;
        }
        }
        System.out.println("----------------------------------------------------");
        System.out.println("City with Most Sales:" + Cities[bestCity]);
        System.out.println("----------------------------------------------------");
        
        
        
    
    }
    
}
